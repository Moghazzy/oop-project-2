package com.company;
import java.util.*;
public class Product
{
    private String productName;
    private double price;
    private int quantity;
    private int quantitySoled;
    private String location;

    public Product()
    {

    }

    public Product(String productName, double price, int quantity)
    {
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getQuantitySoled() {
        return quantitySoled;
    }

    public void setQuantitySoled(int quantitySoled) {
        this.quantitySoled = quantitySoled;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void incrementQuantity(int q) // Increment not set
    {
        quantity += q;

    }

    public void sell(int amount)
    {

        quantity -= amount;
        quantitySoled += amount;
    }
}
