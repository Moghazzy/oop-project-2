package com.company;
import java.util.*;

public class Customer extends Person
{

    //7ane7tagha f form l order 3ashan a3mel beha l object
    public ArrayList<Product> ordercus = new ArrayList<Product>();
    private double totalpurchases = 0;
    private double sale;
    private int id;

    public Customer()
    {

    }

    public Customer(String name, int age, String phoneno, String address, String gender, int id)
    {
        super(name, gender, phoneno, address,age);

        // dh l wa7eed l gdeed
        this.id = id;

    }

    public double getTotalpurchases() {
        return totalpurchases;
    }

    public void setTotalpurchases(double totalpurchases) {
        this.totalpurchases = totalpurchases;
    }

    public double getSale() {
        return sale;
    }

    public void setSale(double sale) {
        this.sale = sale;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public double Salereceet(double cost)
        {
            totalpurchases += cost;

            if (totalpurchases >= 2000)
            {
                sale = 0.50;
            }
            else if (totalpurchases >= 1500)
            {
                sale = 0.35;
            }
            else if (totalpurchases >= 1000)
            {
                sale = 0.10;
            }
            else
            {
                sale = 0;
            }

            return (totalpurchases * (1-sale));
        }


}