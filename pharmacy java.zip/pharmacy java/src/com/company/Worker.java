package com.company;
import java.util.*;
public class Worker extends Person
{
    private int experience;
    private double salary;
    private int id;
    public Worker()
    {

    }

    public Worker(String name, int experience, String address, String phoneno, String gender,int age,int id)
    {
        super(name, address, phoneno, gender,age);
        // take experience & initialise with it the salary
        this.id = id;
        this.experience = experience;
        salary = 1000 * experience;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
         salary=experience*1000;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


     double Salereceet(double cost)
        {
            double sale = 0.1;
            return cost - (cost * sale);
        }

}