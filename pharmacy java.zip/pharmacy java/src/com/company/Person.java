package com.company;
import java.util.*;
public class Person implements Isales {
    private String name;
    private String gender;
    private String phoneno;
    private String address;
    private int age;

    public Person() {

    }

    public Person(String name, String gender, String phoneno, String address, int age) {
        this.name = name;
        this.gender = gender;
        this.address = address;
        this.phoneno = phoneno;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public double salereceet(double cost) {
        return cost;
    }
}