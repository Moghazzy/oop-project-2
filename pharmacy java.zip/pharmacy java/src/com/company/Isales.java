package com.company;

public interface Isales
{
    public double salereceet(double cost);
}
